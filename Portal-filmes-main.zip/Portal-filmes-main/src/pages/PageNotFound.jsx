export default function PageNotFound() {
    return (
        <h1>Página não encontrada</h1>
    )
}