export default function MoviesByGenrePage(){
    return(
        <>
        <h1>Movies By Genre Page</h1>
        {/*Lista todos os filmes do gênero selecionado pelo usuário. */}
        </>
    )
}