export default function MovieDetailPage(){
    return(
        <>
        <h1>Movie Detail Page</h1>
        {/* Exibe detalhes de um filme específico. */}
        </>
    )
}