export default function MovieListPage(){
    return(
        <>
        <h1>Movie List Page</h1>
        {/* Exibe a lista de todos os filmes disponíveis categorizados por gênero.
        Cada filme na lista é mostrado com uma imagem, 
        título e um link para a página de detalhes do filme.*/}
        </>
    )
}