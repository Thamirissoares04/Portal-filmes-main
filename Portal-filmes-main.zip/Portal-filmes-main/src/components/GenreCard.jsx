export default function GenreCard() {
    return(
        <>
        <h1>Genre Card</h1>
        {/* Modelo de card que será utilizado para os gêneros */}
        </>
    )
}