export default function CardContainer() {
    return(
        <>
        <h1>Card Container</h1>
        {/* Container para cards */}
        </>
    )
}