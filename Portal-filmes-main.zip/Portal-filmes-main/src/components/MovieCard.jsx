export default function MovieCard() {
    return(
        <>
        <h1>Movie Card</h1>
        {/* Modelo de card que será utilizado para os filmes */}
        </>
    )

}